// Replace this object with your Firebase Web App configuration.
// Leave apiKey empty to run FlowBoard in local demo mode.
window.FLOWBOARD_FIREBASE_CONFIG = {
  apiKey: "",
  authDomain: "",
  projectId: "",
  storageBucket: "",
  messagingSenderId: "",
  appId: ""
};
