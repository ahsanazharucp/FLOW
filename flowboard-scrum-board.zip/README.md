# FlowBoard — Collaborative Scrum Board

A polished, responsive Scrum board built with plain HTML, CSS, and JavaScript.

## Included features
- Backlog, To Do, In Progress, Review, and Done columns
- Create, edit, delete, search, and filter tasks
- Drag and drop between workflow columns
- Assignees, priority, task label, due date, story points, and blocker status
- Sprint completion, insights, and team views
- Responsive desktop/mobile layout and keyboard-friendly task opening
- Local browser persistence by default
- Optional Firebase Firestore real-time multi-user synchronization

## Run locally
Because JavaScript modules are used, serve the folder through a local web server:

```bash
python3 -m http.server 8000
```
Then open `http://localhost:8000`.

## Enable real-time multi-user access
1. Create a Firebase project at https://console.firebase.google.com/.
2. Add a Web App and copy its configuration values into `firebase-config.js`.
3. In Firebase Authentication, enable **Anonymous** sign-in.
4. Create a Firestore database.
5. For a quick classroom/demo deployment, use the rules below. For production, use stronger authenticated membership rules.
6. Deploy the folder to Firebase Hosting, GitHub Pages, Netlify, Azure Static Web Apps, or another static host.

### Demo Firestore rules
```
rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    match /boards/{boardId}/tasks/{taskId} {
      allow read, write: if request.auth != null;
    }
  }
}
```

These rules allow any anonymously authenticated visitor to the deployed board to edit it. For a production system, restrict access by organization, board membership, or approved email domain.

## Files
- `index.html`: page structure
- `styles.css`: responsive visual design
- `script.js`: board behavior and Firebase integration
- `firebase-config.js`: your Firebase connection settings
